#include <stdio.h>
#include <iostream>
#include<string>
#include"app.h"

int main() {
    printf("Hello World\n");

    app::simpleMath();

    app::simpleInput();
    
    return 0;
}
